# JARVIS Phone Control — Android Java Starter

Native Android Java prototype for an assistant-style dashboard with speech-to-text, text-to-speech, configurable OpenRouter-compatible chat API, a Canvas-drawn sci-fi reactor, quick phone actions, app/site shortcuts, and optional Accessibility Service actions.

## Build
Open the project in Android Studio or use a compatible GitHub Actions Android build workflow. This repository does not include a Gradle wrapper, so a workflow must install/use a compatible Gradle version and Android SDK. No APK is included in this source ZIP.

## Important limitations
- The app has not been compiled or tested on a physical device in this package-generation environment.
- AI requires your own API key; model availability, quotas and cost depend on the provider.
- Speech recognition depends on Android's installed recognition service.
- Home/back/notifications/quick settings and lock-screen actions require enabling the Accessibility Service; Android may restrict some actions.
- Gmail, Telegram and Discord shortcuts open their web apps/sites only. Private message reading/sending, Discord server moderation/support automation, downloading videos, and always-on wake-word listening are not implemented.
- Do not place API keys in source code or commit them to GitHub.
