package com.varun.jarviscontrol;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Part 1: configurable AI reasoning/chat layer. No API key is bundled in the app. */
public final class JarvisBrain {
    public interface Callback { void onResult(String reply, String action, String error); }
    private final Context context;
    private final SharedPreferences prefs;
    public JarvisBrain(Context c) { context=c.getApplicationContext(); prefs=context.getSharedPreferences("jarvis_brain", Context.MODE_PRIVATE); }
    public String getModel() { return prefs.getString("model", "openrouter/free"); }
    public boolean isConfigured() { return !prefs.getString("api_key", "").trim().isEmpty(); }
    public void saveConfig(String key, String model) { prefs.edit().putString("api_key", key.trim()).putString("model", model.trim().isEmpty()?"openrouter/free":model.trim()).apply(); }
    public void ask(String userText, Callback callback) {
        final String key=prefs.getString("api_key", "").trim();
        final String model=prefs.getString("model", "openrouter/free").trim();
        if(key.isEmpty()) { callback.onResult(null, null, "AI brain isn't connected yet. Tap AI SETUP and add your own API key. You can still use supported local commands."); return; }
        new Thread(() -> {
            HttpURLConnection conn=null;
            try {
                URL url=new URL("https://openrouter.ai/api/v1/chat/completions");
                conn=(HttpURLConnection)url.openConnection(); conn.setRequestMethod("POST"); conn.setConnectTimeout(20000); conn.setReadTimeout(30000); conn.setDoOutput(true);
                conn.setRequestProperty("Authorization", "Bearer "+key); conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                JSONObject body=new JSONObject(); body.put("model", model); body.put("temperature", 0.4); body.put("max_tokens", 700);
                JSONArray messages=new JSONArray();
                JSONObject system=new JSONObject(); system.put("role","system"); system.put("content",
                    "You are JARVIS, a concise helpful Android personal assistant. Understand natural language, reason carefully, and never claim an action was completed unless the app confirms it. You may request only these supported tools: home, back, notifications, quick_settings, open_youtube, open_google, open_chrome, open_settings. Return ONLY valid JSON with keys reply and action. action must be one of none, home, back, notifications, quick_settings, open_youtube, open_google, open_chrome, open_settings. If user asks for anything else (including Gmail, Telegram, Discord, downloading videos, reading messages, sending messages, or background actions), set action to none and explain that integration is not implemented yet. Never request passwords or secrets in chat. Ask for confirmation before potentially consequential actions; currently do not execute consequential actions."); messages.put(system);
                JSONObject user=new JSONObject(); user.put("role","user"); user.put("content",userText); messages.put(user); body.put("messages",messages);
                byte[] bytes=body.toString().getBytes(StandardCharsets.UTF_8); try(OutputStream os=conn.getOutputStream()){os.write(bytes);}
                int code=conn.getResponseCode(); InputStream stream=(code>=200&&code<300)?conn.getInputStream():conn.getErrorStream();
                StringBuilder sb=new StringBuilder(); try(BufferedReader br=new BufferedReader(new InputStreamReader(stream,StandardCharsets.UTF_8))){String line;while((line=br.readLine())!=null)sb.append(line);}
                String rawResponse=sb.toString();
                JSONObject response;
                try { response = new JSONObject(rawResponse); }
                catch (Exception parseError) {
                    throw new Exception("AI service returned an unreadable response. Please retry; if it repeats, check the selected model.");
                }
                if(code<200||code>=300) {
                    JSONObject err=response.optJSONObject("error");
                    String detail=err==null?response.optString("message", ""):err.optString("message", "");
                    if(detail.isEmpty()) detail="Check your API key, model ID, connection, and free-tier availability.";
                    throw new Exception("AI service returned HTTP "+code+": "+detail);
                }
                JSONArray choices=response.optJSONArray("choices");
                if(choices==null || choices.length()==0) {
                    throw new Exception("AI provider returned no choices. Try again or select another available model.");
                }
                JSONObject choice=choices.optJSONObject(0);
                JSONObject message=choice==null?null:choice.optJSONObject("message");
                if(message==null) throw new Exception("AI provider response is missing its message. Try another model.");
                Object contentValue=message.opt("content");
                String content="";
                if(contentValue instanceof String) content=((String)contentValue).trim();
                else if(contentValue instanceof JSONArray) {
                    JSONArray parts=(JSONArray)contentValue;
                    StringBuilder joined=new StringBuilder();
                    for(int i=0;i<parts.length();i++) {
                        JSONObject part=parts.optJSONObject(i);
                        if(part!=null) { String txt=part.optString("text", ""); if(!txt.isEmpty()) { if(joined.length()>0) joined.append('\n'); joined.append(txt); } }
                    }
                    content=joined.toString().trim();
                }
                if(content.isEmpty()) throw new Exception("AI provider returned an empty reply. Try again or select another model.");
                // Accept either the requested JSON format or ordinary natural-language text.
                String cleaned=content.replaceAll("^```(?:json)?\\s*", "").replaceAll("\\s*```$", "").trim();
                String reply; String action="none";
                try {
                    JSONObject answer=new JSONObject(cleaned);
                    reply=answer.optString("reply", cleaned);
                    action=answer.optString("action", "none");
                } catch(Exception notJson) {
                    reply=cleaned;
                }
                if(!action.equals("none") && !action.matches("home|back|notifications|quick_settings|open_youtube|open_google|open_chrome|open_settings")) action="none";
                callback.onResult(reply, action, null);
            } catch(Exception e) { callback.onResult(null,null,"AI request failed: "+(e.getMessage()==null?"unknown error":e.getMessage())); }
            finally { if(conn!=null)conn.disconnect(); }
        }).start();
    }
}
